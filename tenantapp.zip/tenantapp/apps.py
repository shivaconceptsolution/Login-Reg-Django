from django.apps import AppConfig


class TenantappConfig(AppConfig):
    name = 'tenantapp'
