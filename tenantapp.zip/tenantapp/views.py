from django.shortcuts import render,redirect
from django.http import HttpResponse

def index(request):
 if(request.session.has_key('uname')):
 	u = request.session["uname"]
 	return render(request,"tenantapp/index.html",{"res":u})
 else:
    return redirect('/guestapp/tlogin') 	

def logout(request):
	del request.session["uname"]
	return redirect('/guestapp/tlogin')